# EPDDL Benchmarks — Escenarios de Robótica Multi-Agente

Colección de benchmarks en EPDDL para usar con
[Plank](https://github.com/a-burigana/plank).

---

## Estructura de carpetas

```
epddl-workspace/
├── box-task/                   ← Escenario original (simple, 2 robots)
│   ├── box-task-domain.epddl
│   ├── box-task-problem.epddl
│   ├── robot-lib.epddl
│   └── validate.sh
│
└── robot-warehouse/            ← Escenario nuevo (complejo, 3 robots, 4 zonas)
    ├── warehouse-domain.epddl
    ├── warehouse-problem.epddl
    ├── warehouse-lib.epddl
    ├── validate.sh
    └── export_out/
```

---

## Escenario 1 — `box-task` (original)

| Elemento       | Detalle                                             |
|----------------|-----------------------------------------------------|
| Agentes        | `r1` (inspector), `r2` (recolector)                 |
| Zonas          | A, B                                                |
| Meta           | `holding(r2)` ∧ `[r1](holding(r2))`                |
| Acciones clave | `observe-private-A`, `pickup-A-hold`, `pickup-A-clear` |
| Complejidad    | Pequeña — 6 predicados, 6 eventos, 6 acciones       |

---

## Escenario 2 — `robot-warehouse` (nuevo, más complejo)

### Contexto

Almacén industrial con tres robots de roles diferenciados y cuatro zonas
conectadas en cadena `Z1 ↔ Z2 ↔ Z3 ↔ Z4`.

| Robot       | Rol                                                          |
|-------------|--------------------------------------------------------------|
| `r_scout`   | Explorador: inspecciona zonas en **privado** con sus sensores |
| `r_carrier` | Portador: recoge y transporta piezas dañadas                 |
| `r_super`   | Supervisor: recibe reportes y activa la alarma general       |

### Topología de zonas

```
[Z1: Entrada] ↔ [Z2: Estantería-A] ↔ [Z3: Estantería-B] ↔ [Z4: Salida]
```

- Z2 tiene un **obstáculo** (conocido por todos)
- Z3 tiene una **pieza dañada** (solo se descubre inspeccionando)

### Meta del problema

```
(piece-removed-Z3)              ; hecho físico: pieza retirada
([r_super] (piece-removed-Z3))  ; epistémico:   supervisor lo sabe
(alarm-raised)                  ; hecho físico: alarma activa
([C. All] (alarm-raised))       ; epistémico:   conocimiento común
```

### Por qué la meta epistémica importa

Sin el reporte privado `r_scout → r_super`, el supervisor puede activar
la alarma pero **no tendrá la creencia** `[r_super](piece-removed-Z3)`.
El **Plan B** en `validate.sh` demuestra exactamente este fallo.

### Predicados del mundo

| Predicado              | Significado                          |
|------------------------|--------------------------------------|
| `at-ZN ?r`             | robot `r` está en zona `ZN`          |
| `obstacle-ZN`          | hay obstáculo en zona `ZN`           |
| `piece-damaged-ZN`     | hay pieza dañada en `ZN`             |
| `piece-carried ?r`     | `r` lleva una pieza                  |
| `zone-clear-ZN`        | zona `ZN` sin obstáculos             |
| `piece-removed-ZN`     | pieza retirada de `ZN`               |
| `inspected-ZN ?r`      | `r` inspeccionó `ZN`                 |
| `alarm-raised`         | alarma general activada              |
| `report-sent ?r`       | `r` envió reporte                    |

### Tipos de observabilidad

| Acción                          | Observabilidad                          |
|---------------------------------|-----------------------------------------|
| `move-to-ZN`, `pickup-*`, etc.  | `Fully` para todos (pública)            |
| `inspect-private-ZN`            | `Fully` para el actor, `Oblivious` resto|
| `report-damage-ZN`, etc.        | `Fully` para sender+receptor, `Oblivious` resto |
| `raise-alarm`                   | `Fully` para todos (conocimiento común) |

---

## Uso con Plank

```bash
# Reemplaza LIB con la ruta correcta a tu instalación de plank
LIB=~/plank/benchmarks/libraries/intermediate.epddl

# Parsear
plank parse -d warehouse-domain.epddl -p warehouse-problem.epddl -l $LIB

# Validar Plan A (correcto)
bash robot-warehouse/validate.sh
```

---

## Diferencias clave respecto a `box-task`

| Característica           | `box-task`     | `robot-warehouse`              |
|--------------------------|----------------|--------------------------------|
| Agentes                  | 2              | 3 (roles diferenciados)        |
| Zonas/locaciones         | 2              | 4 (topología en cadena)        |
| Predicados               | 6              | 18                             |
| Eventos                  | 7              | 18                             |
| Acciones                 | 6              | 20                             |
| Tipos de observabilidad  | 2              | 3                              |
| Meta epistémica          | `K_r1`         | `K_r_super` + `C_All`          |
| Conocimiento común       | No             | Sí (alarma)                    |
| Comunicación privada     | 1 canal        | 4 canales (reportes)           |
| Planes de validación     | 2              | 3 (incl. un plan inválido)     |
