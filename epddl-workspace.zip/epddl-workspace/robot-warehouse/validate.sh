#!/bin/bash
# =============================================================================
# validate.sh — Ejecuta parse, ground y validate para warehouse-inspection-1
# Requiere: plank (https://github.com/a-burigana/plank)
# Uso: bash validate.sh
# =============================================================================

LIB=~/plank/benchmarks/libraries/intermediate.epddl
DOMAIN=warehouse-domain.epddl
PROBLEM=warehouse-problem.epddl

echo "============================================================"
echo " PARSE"
echo "============================================================"
plank parse \
  -d $DOMAIN \
  -p $PROBLEM \
  -l $LIB

echo ""
echo "============================================================"
echo " GROUND"
echo "============================================================"
plank ground \
  -d $DOMAIN \
  -p $PROBLEM \
  -l $LIB

# =============================================================================
# Plan A: Scout inspecciona Z3 en privado → reporta al supervisor →
#         carrier va a Z3 → recoge pieza (x2) → supervisor activa alarma
# =============================================================================
echo ""
echo "============================================================"
echo " VALIDATE — Plan A (inspección + reporte + recogida + alarma)"
echo "============================================================"
plank validate \
  -d $DOMAIN \
  -p $PROBLEM \
  -l $LIB \
  -a \
    "move-to-Z2_r_scout" \
    "move-to-Z3_r_scout" \
    "inspect-private-Z3_r_scout" \
    "report-damage-Z3_r_scout_r_super" \
    "move-to-Z2_r_carrier" \
    "move-to-Z3_r_carrier" \
    "pickup-damaged-Z3-carry_r_carrier" \
    "pickup-damaged-Z3-clear_r_carrier" \
    "raise-alarm_r_super"

# =============================================================================
# Plan B (inválido a propósito): carrier intenta recoger sin scout previo.
#         El supervisor no tendrá el conocimiento epistémico requerido.
#         Útil para verificar que la meta epistémica falla sin el reporte.
# =============================================================================
echo ""
echo "============================================================"
echo " VALIDATE — Plan B (sin reporte: meta epistémica debe FALLAR)"
echo "============================================================"
plank validate \
  -d $DOMAIN \
  -p $PROBLEM \
  -l $LIB \
  -a \
    "move-to-Z2_r_carrier" \
    "move-to-Z3_r_carrier" \
    "pickup-damaged-Z3-carry_r_carrier" \
    "pickup-damaged-Z3-clear_r_carrier" \
    "raise-alarm_r_super"

# =============================================================================
# Plan C: Variante — scout también despeja el obstáculo de Z2 antes
#         de inspeccionar Z3.
# =============================================================================
echo ""
echo "============================================================"
echo " VALIDATE — Plan C (scout despeja Z2 primero)"
echo "============================================================"
plank validate \
  -d $DOMAIN \
  -p $PROBLEM \
  -l $LIB \
  -a \
    "move-to-Z2_r_scout" \
    "clear-obstacle-Z2_r_scout" \
    "move-to-Z3_r_scout" \
    "inspect-private-Z3_r_scout" \
    "report-damage-Z3_r_scout_r_super" \
    "move-to-Z2_r_carrier" \
    "move-to-Z3_r_carrier" \
    "pickup-damaged-Z3-carry_r_carrier" \
    "pickup-damaged-Z3-clear_r_carrier" \
    "raise-alarm_r_super"
